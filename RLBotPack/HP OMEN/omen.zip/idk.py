from random import randint
f=open("data.txt", "a+")
def getdatarandom():
  repeattimes = input("How many dice should I simulate for? \n")
  dice = 1
  for i in range(int(repeattimes)):
    list1 = []
    list2 = []
    templist1 = []
    timerepeat1 = 500000*dice
    for i in range(timerepeat1):
      templist1 = []
      for i in range(int(dice)):
        templist1.append(randint(1, 6))
      list1.append(sum(templist1))
    for i in range(int(dice)*6):
        list2.append(0)
    for i in list1:
        list2[i-1] = list2[i-1] + 1
    f.write("Percent occured with " + str(dice) + " dice:\n")
    for i in range(len(list2)):
        list2[i] = (int((list2[i]/6**dice)*1000000))/10000
    print(list2)
    for i in range(len(list2)):
        f.write(str(i + 1) + ": " + str(list2[i]) + "\n")
    f.write("\n")
    print("Done with " + str(dice) + " dice")
    dice += 1
    f.close()
def getdatanormal():
  repeattimes = input("How many dice should I simulate for? \n")
  dice = 1
  for i in range(int(repeattimes)):
      list1 = []
      list2 = []
      timelist = []
      for i in range(dice):
          timelist.append(1)
      for i in range((6**dice)):
        for i in range(dice):
              if timelist[i] == 7 and not i == 0:
                  timelist[i-1] += 1
                  timelist[i] = 1
        list1.append(sum(timelist))
        timelist[dice-1] += 1
      for i in range(int(dice)*6):
          list2.append(0)
      for i in list1:
          list2[i-1] = list2[i-1] + 1
      f.write("Percent occured with " + str(dice) + " dice:\n")
      for i in range(len(list2)):
        list2[i] = (int((list2[i]/6**dice)*1000000))/10000
      for i in range(len(list2)):
          f.write(str(i + 1) + ": " + str(list2[i]) + "\n")
      f.write("\n")
      print("Done with " + str(dice) + " dice")
      dice += 1
  f.close()
whichone = input("which type of data collection would you like? (1 for random, 2 for realistic projection)\n")
if whichone == "1":
  getdatarandom()
else:
  getdatanormal()