import time

elapsed = 0

while elapsed < 43:
    time.sleep(0.2)
    elapsed = elapsed + 1