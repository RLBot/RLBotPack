from rlbot.agents.base_scratch_agent import BaseScratchAgent


class ScratchBot(BaseScratchAgent):
    pass
