# RLBotScratchInterface
Allows the Scratch programming language to control RLBot.

## Quick Start

- Follow this guide to install RLBot: https://youtu.be/YJ69QZ-EX7k
- When we choose python in the video, choose Scratch instead.
- In the GUI, put your bot on a team and start the match. The scratch editor will open!
- Get some tips here: https://youtu.be/c6rsBEqx22c
